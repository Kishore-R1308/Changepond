import React from 'react'

const GreetComp = () => {
  return (
    <div>
        Good Afternoon All My Dear Friends
    </div>
  )
}

export default GreetComp