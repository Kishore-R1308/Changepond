import React from 'react'

const img = () => {
  return (
    <div>
    <div>
         <img title="Ai generated image" 
         src="https://www.google.com/imgres?q=ai%20images&imgurl=https%3A%2F%2Fwww.technewsworld.com%2Fwp-content%2Fuploads%2Fsites%2F3%2F2025%2F02%2Fhumanoid-robot-programming-code.jpg&imgrefurl=https%3A%2F%2Fwww.technewsworld.com%2Fstory%2Fai-in-2025-generative-tech-robots-and-emerging-risks-179587.html&docid=9mblYfoy_9UX4M&tbnid=NlqhXC94a7zSwM&vet=12ahUKEwjJm8P2lsySAxU9SWwGHZpkPMoQnPAOegQIGhAB..i&w=1000&h=520&hcb=2&ved=2ahUKEwjJm8P2lsySAxU9SWwGHZpkPMoQnPAOegQIGhAB" 
         alt='description'
         />
      
      </div>
     
    </div>
  )
}

export default img