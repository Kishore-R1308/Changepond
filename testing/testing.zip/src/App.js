//import logo from './logo.svg';
import './App.css';

function App() {
  return (
    <div className="App">
      
      {/* <header className="App-header">
        <img src={logo} className="App-logo" alt="logo" />
        <p>
          Edit <code>src/App.js</code> and save to reload.
        </p>
        <a
          className="App-link"
          href="https://reactjs.org"
          target="_blank"
          rel="noopener noreferrer"
        >
          Learn React
        </a>
      </header> */}
      <div>
        <input type='text' placeholder='Enter user name' name="username" id="userID" />
         <img title="Ai generated image"
          src="https://www.google.com/imgres?q=ai%20images&imgurl=https%3A%2F%2Fimages.stockcake.com%2Fpublic%2Fc%2F6%2F1%2Fc61942d7-9bc6-48a9-9683-5f5a71e87201_large%2Ffuturistic-ai-portrait-stockcake.jpg&imgrefurl=https%3A%2F%2Fstockcake.com%2Fi%2Ffuturistic-ai-portrait_1015818_230335&docid=er8O2So7Rt0ZgM&tbnid=3V4Iyrp0TCkiyM&vet=12ahUKEwjJm8P2lsySAxU9SWwGHZpkPMoQnPAOegQIHBAB..i&w=512&h=512&hcb=2&ved=2ahUKEwjJm8P2lsySAxU9SWwGHZpkPMoQnPAOegQIHBAB"/>
          </div> 



    </div>
  );
}

export default App;
