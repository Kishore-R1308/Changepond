import React from "react";

const SumComp = (num1,num2) => {
    return num1+num2;
}

export default SumComp