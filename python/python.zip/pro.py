str = "Hellow world"
print("org",str)
print(str[1])
print(str[3:])
print(str[:3])
print(str[3:7])
print(str[::-1])
print(str.find("world"))
print(str.upper())
print("*"*50)
print(str.capitalize())
print(str.title())
      
