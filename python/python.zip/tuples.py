continents = ("Antartica","Asia","Africa","North America","South America",
              "Australia","Europe")
print(continents[0])
