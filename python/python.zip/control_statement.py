#Leap year
"""
#method 1:
x = 3002
if((x%400 == 0) |((x%100 !=0)&(x%4 == 0))):
    print(x ,"is leap year")
else:
    print(x ,"is not leap year")

#method 2:
y= 2000
if(y%400 == 0):
    print(y ,"is leap year")
elif((y%100 !=0)&(y%4 == 0)):
    print(y ,"is leap year")
else:
    print(y ,"is not leap year")


start_y = int(input("start year:"))
end_y = int(input("End year:"))
print("List of leap years:")
for x in range(start_y,end_y):
    if((x%400 == 0) |((x%100 !=0)&(x%4 == 0))):
        print(x ,"is leap year")"""


#ASSIGNMENT:





    
            
    
