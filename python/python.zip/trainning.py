shape = "Rectangele"
length = 10
width = 15
issquare = True

print(shape,type(shape))
print(length,type(length))
print(width,type(width))
print(issquare,type(issquare))



#Operators
num1 = 10
num2 = 20
print( num1,"+",num2,"=",num1+num2)
print( num1,"-",num2,"=",num1-num2)
print( num1,"*",num2,"=",num1*num2)
print( num1,"/",num2,"=",num1/num2)
print( num1,"%",num2,"=",num1%num2)
print( num1,"//",num2,"=",num1//num2)


