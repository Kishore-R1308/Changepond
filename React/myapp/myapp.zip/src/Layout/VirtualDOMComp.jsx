import React from 'react'


const VirtualDOMComp = () => {
  return (
    <div>
        <h2> this is virtualDOMComp</h2>
    </div>
  )
}

export default VirtualDOMComp