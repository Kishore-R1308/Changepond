import React from 'react'

const PafeNotFoundComp = () => {
  return (
    <div>
       <h2 style={{ color: 'red'}}> 404 Page not found</h2>
    </div>
  )
}

export default PafeNotFoundComp