

const FunctionComp=(props) =>{
  return (
    <div>
      {`Function: ${props.uname} and ${props.id} and ${props.company}` }
    </div>
  )
}

export default FunctionComp