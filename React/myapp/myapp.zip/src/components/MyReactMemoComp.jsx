import React from 'react'

const MyReactMemoComp = () => {
  console.log("this is pure memo")
  return (
    <div>
        This is ReactMemoComp
    </div>
  )
}

export default MyReactMemoComp
