import React from 'react'

function Toggle6Comp() {
  return (
    <div style={ {textAlign: 'center'}}>

        <h2> Toggle Image</h2>

        


    </div>
  )
}

export default Toggle6Comp