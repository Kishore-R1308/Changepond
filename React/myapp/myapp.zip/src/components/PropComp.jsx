
import ClassComp from './ClassComp'
import FunctionComp from './FunctionComp';
const PropComp=() =>{
  return (
    <div>
      <ClassComp u="Kishore" id="5" /><br />
      <FunctionComp uname="CHANGEPOND" id="3" company="dell"/>
    </div>
  )
}

export default PropComp