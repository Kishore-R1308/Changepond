import React from 'react'

const MyPureComp = () => {
render(){
   

  return (
    <div>M
        This is Pure Comp
    </div>
  )
}
}

export default MyPureComp