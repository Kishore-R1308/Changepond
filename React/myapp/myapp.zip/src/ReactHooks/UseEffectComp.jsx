import React from 'react'

const UseEffectComp = () => {
  return (
    <div>This is use effect</div>
  )
}

export default UseEffectComp