import dosa from '../images/dosa.png'
import jalebi from '../images/jalebi.jpg';
import samosa from '../images/samosa.png';
;

const constData={
    dosa,jalebi,samosa
}

export default constData;