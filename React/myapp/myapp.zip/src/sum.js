import React from 'react'

const sum = (a,b) => {
  return a+b
}

export default sum